<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Expenses extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('expense_model');
	}
	public function index() //shows all travel links of a particular user
	{
		$data['data']= $this->expense_model->get_all_expenses();
		$data['contents'] = "expense/expense_page";
		$this->load->view('layouts/navbar',$data);		
		
	}
	public function travel_specific() //shows all travel links of a particular user
	{
		$data['data']= $this->expense_model->get_travel_specific_expenses();
		$data['contents'] = "expense/expense_travel_specific";
		$this->load->view('layouts/navbar',$data);
		
	}
}