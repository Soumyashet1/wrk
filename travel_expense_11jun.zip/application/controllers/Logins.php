<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Logins extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Login_model');
	}
	public function index()
	{
		$email = $this->input->post("email");
		$password = $this->input->post("pass");
		$uresult = $this->Login_model->get_user($email, $password);
		if (count($uresult) > 0)
			{
			    $sess_data = array('login' => TRUE, 'uname' => $uresult[0]->first_name, 'uid' => $uresult[0]->employee_id,'urole' => $uresult[0]->employee_role_id);
				$this->session->set_userdata($sess_data);
				if ( $uresult[0]->employee_role_id == 2)// if Login credentials are of employees den redirect to expense controller
				{
					redirect("expenses");
				}
				else {
					redirect("/logins/employee");//else redirect to admin controller
				}
			}
			else
			{
				$this->load->view('login/login_page');//load the  same page if credentials r wrong
			}
	}
	public function users()
	{
		$data['user']=$this->Login_model->get_all_users();
		$data['contents'] = "login/users";
		$this->load->view('layouts/navbar',$data);
	}
	public function employee()//////////combing content wit nav bar
	{
    $data['expense']=$this->Login_model->get_user_specific_expenses();
		$data['contents'] = "content";
		$this->load->view('layouts/navbar',$data);
	}
  public function expenses_of_travel()
  {
    $data['expense']=$this->Login_model->get_user_and_travel_specific_expenses();
    $data['contents'] = "login/expense_of_travel";
    $this->load->view('layouts/navbar',$data);
  }
	public function logout()
	{
		// destroy session
		$data = array('login' => '', 'uname' => '', 'uid' => '');
		$this->session->unset_userdata($data);
		$this->session->sess_destroy();
		redirect('/Logins');
	}
}
