<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Travel_model extends CI_Model
{
	var $table = 'travels';
	public function __construct()
	{
		parent::__construct();
	}
    public function get_all_travels()//shows all travels list
    {
			$query = $this->db->query("SELECT t.travel_id,t.travel_name,t.travel_desc,
GROUP_CONCAT(DISTINCT emp.first_name) as Employees,t.travel_start_date,t.travel_end_date,
ts.travel_status_name as status
FROM travels t
LEFT JOIN travel_statuses ts ON t.travel_status_id=ts.travel_status_id
LEFT JOIN travels_assigned ta ON t.travel_id=ta.travel_id
LEFT JOIN employees emp ON ta.employee_id=emp.employee_id
GROUP BY t.travel_id");
			return $query->result();
    }
}
