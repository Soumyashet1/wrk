<?php
class Login_model extends CI_Model {
public function __construct()
{
         parent::__construct();
}
public function get_user($email, $pwd)
{
		$this->db->where('email_id', $email);
		$this->db->where('password',($pwd));
    $query = $this->db->get('employees');
		return $query->result();
}
public function get_all_users()
{
  $query = $this->db->query("SELECT e.employee_id,e.first_name,e.last_name,e.email_id,r.role_name,d.department_name
FROM employees e
LEFT JOIN roles r ON e.employee_role_id=r.role_id
LEFT JOIN departments d ON d.department_id=e.department_id");
  return $query->result();
 }
 public function get_user_specific_expenses()///shows all travel of particular user with sum of price
 {
   $query = $this->db->query("SELECT t.travel_id,t.travel_name,t.travel_desc,t.travel_start_date,t.travel_end_date,SUM(e.expense_price) as Total_price FROM travels t
LEFT JOIN travels_assigned ta ON  t.travel_id=ta.travel_id
LEFT JOIN expenses e ON ta.travel_assigned_id=e.expense_travel_assigned_id
LEFT JOIN employees emp ON ta.employee_id=emp.employee_id
WHERE emp.employee_id=1121
GROUP BY t.travel_id");
   return $query->result();
  }
  public function get_user_and_travel_specific_expenses()//shows expenses of a particular user n travel
  {
    $query = $this->db->query("SELECT e.expense_id,e.expense_date,e.expense_time,
ec.expense_category_name,e.expense_desc,e.expense_price,es.expense_status_name
FROM expenses e
LEFT JOIN expense_statuses es ON e.expense_status_id=es.expense_status_id
LEFT JOIN expense_categories ec ON e.expense_category_id=ec.expense_category_id
LEFT JOIN travels_assigned ta ON e.expense_travel_assigned_id=ta.travel_assigned_id
WHERE  ta.travel_id=4
AND ta.employee_id=1119
ORDER BY e.expense_id");
    return $query->result();
   }

}
?>
