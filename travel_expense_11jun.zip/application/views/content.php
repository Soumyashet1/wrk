<div class="container">
<h1>Expenses of Travels</h1>
<?php foreach($expense as $usr){?>
  <div class="panel panel-danger">
	  <div class="panel-heading">
	    <div class="row">
	    <div class=col-sm-2><h3 class="panel-title"><?php echo $usr->travel_id;?>.<?php echo $usr->travel_name;?></h3></div>
	     <div  style="text-align:right"><h3 class="panel-title"><span><?php echo $usr->travel_start_date;?> - <?php echo $usr->travel_end_date;?></span></h3></div>
	    </div>
	  </div>
	  <div class="panel-body">
		  <div class="row">
		    <div class=col-sm-2><h3 class="panel-title"><?php echo $usr->travel_desc;?></h3></div>
		     <div style="text-align:right"><h3 class="panel-title"><span><?php echo $usr->Total_price;?>/-</span></h3></div>
		  </div>
	  </div>
  </div>
  <?php }?>
</div>
