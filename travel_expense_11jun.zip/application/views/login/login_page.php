<html>
<head></head>
<body>
<div class="">
<form action="" method="post">
User Name<input type="email" name="email" required>
password<input type="password" name="pass" required>
<input type="submit" value="login">
</form>
</div>
</body>
</html>