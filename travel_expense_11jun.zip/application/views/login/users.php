<div class="container">
<h1>Travels</h1>
<table class="table table-bordered">
    <thead>
      <tr>
        <th>Employee_id</th>
        <th>First_Name</th>
        <th>Last_Name</th>
        <th>Email-id</th>
        <th>Employee_role_id</th>
        <th>department_id</th>
        <th>Actions</th>
       </tr>
    </thead>
    <tbody>
      <?php foreach($user as $usr){?>
	  <tr>
		<td><?php echo $usr->employee_id;?></td>
		<td><?php echo $usr->first_name;?></td>
		<td><?php echo $usr->last_name;?></td>
		<td><?php echo $usr->email_id;?></td>
		<td><?php echo $usr->role_name;?></td>
    <td><?php echo $usr->department_name;?></td>
    <td>									<button class="btn btn-warning" ><i class="glyphicon glyphicon-pencil"></i></button>
    									<button class="btn btn-danger" ><i class="glyphicon glyphicon-remove"></i></button>
    </td>
       </tr>
      <?php }?>
    </tbody>
  </table>
</div>
