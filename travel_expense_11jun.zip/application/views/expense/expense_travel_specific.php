<div class="container">
<h1>Expenses</h1>
 <!-- Centered Pills -->
<ul class="nav nav-pills nav-justified">
  <li class="active"><a href="#">All</a></li>
  <li><a href="#">Pending</a></li>
  <li><a href="#">Accepted</a></li>
  <li><a href="#">Rejected</a></li>   
</ul>
<br>
<br>
<table class="table table-bordered">
    <thead>
      <tr>
        <th>Expense_id</th>
        <th>Employee_Name</th>
        <th>Expense_Date</th>
        <th>Expense_Time</th>
        <th>Expense_category_name</th>
        <th>Expense_Description</th>
        <th>Expense_Price</th>
        <th>Expense_Status</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($data as $usr){?>
	  <tr>
		<td><?php echo $usr->expense_id;?></td>
		<td><?php echo $usr->first_name;?></td>
		<td><?php echo $usr->expense_date;?></td>
		<td><?php echo $usr->expense_time;?></td>
		<td><?php echo $usr->expense_category_name;?></td>
        <td><?php echo $usr->expense_desc;?></td>
        <td><?php echo $usr->expense_price;?></td>
        <td><?php echo $usr->expense_status_name;?></td>        
      </tr>
      <?php }?>
    </tbody>
  </table>
</div>