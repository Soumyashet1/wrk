<?php
class Login_model extends CI_Model {
public function __construct()
{
         parent::__construct();
}
public function get_user($email, $pwd)
{
		$this->db->where('email_id', $email);
		$this->db->where('password',($pwd));
        $query = $this->db->get('employees');
		return $query->result();
	}
 
 public function get_all_users()
 {
 	$this->db->from('employees');
 	$query=$this->db->get();
 	return $query->result();
 }
}
?>