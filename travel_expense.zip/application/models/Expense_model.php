<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Expense_model extends CI_Model
{
	var $table = 'expenses';
	public function get_all_expenses()
	{
		$query = $this->db->query("SELECT t.travel_id,t.travel_name,GROUP_CONCAT(DISTINCT emp.first_name) as Employees,t.travel_start_date,t.travel_end_date,SUM(e.expense_price) as Total_price
FROM travels t
join travels_assigned ta on t.travel_id=ta.travel_id
join expenses e on ta.travel_assigned_id=e.expense_travel_assigned_id
join employees emp on ta.employee_id=emp.employee_id
GROUP BY t.travel_id");
		
		return $query->result();
	}
	public function get_travel_specific_expenses()
	{
		$query = $this->db->query("SELECT e.expense_id,ep.first_name,e.expense_date,e.expense_time,
ec.expense_category_name,e.expense_desc,e.expense_price,es.expense_status_name
FROM expenses e,expense_statuses es,travels t, travels_assigned ta,employees ep,expense_categories ec
WHERE e.expense_status_id=es.expense_status_id
AND e.expense_travel_assigned_id=ta.travel_assigned_id
AND ta.travel_id=t.travel_id
AND ta.employee_id=ep.employee_id
AND e.expense_category_id=ec.expense_category_id
AND t.travel_id=1
ORDER BY e.expense_id");
		
		return $query->result();
	}
}
