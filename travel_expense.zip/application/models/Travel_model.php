<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Travel_model extends CI_Model
{
	var $table = 'travels';
	public function __construct()
	{
		parent::__construct();
	}
    public function get_all_travels()//shows all travels list
    {
        $this->db->from('travels');
        $query=$this->db->get();
        return $query->result();
    }
}