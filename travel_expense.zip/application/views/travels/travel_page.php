<div class="container">
<h1>Travels</h1>
<table class="table table-bordered">
    <thead>
      <tr>
        <th>Travel_id</th>
        <th>Travel_Name</th>
        <th>Employess_Assigned</th>
        <th>Travel_Description</th>
        <th>Travel_Start_Date</th>
        <th>Travel_End_Date</th>
        <th>Travel_status</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($travel as $usr){?>
	  <tr>
		<td><?php echo $usr->travel_id;?></td>
		<td><?php echo $usr->travel_name;?></td>
		<td><?php echo $usr->travel_id;?></td>
		<td><?php echo $usr->travel_desc;?></td>
		<td><?php echo $usr->travel_start_date;?></td>
        <td><?php echo $usr->travel_end_date;?></td>
        <td><?php echo $usr->travel_status_id;?></td>
      </tr>
      <?php }?>
    </tbody>
  </table>
</div>