<div class="container">
<h1>Expenses</h1>
  <div class="panel panel-danger">
	  <div class="panel-heading">
	    <div class="row">
	    <div class=col-sm-2><h3 class="panel-title">Travel1</h3></div>
	     <div  style="text-align:right"><h3 class="panel-title"><span>25 may 2017 - 28 may 2017</span></h3></div>
	    </div>
	  </div>
	  <div class="panel-body">
		  <div class="row">
		    <div class=col-sm-2><h3 class="panel-title">Suraj,Ramesh</h3></div>
		     <div style="text-align:right"><h3 class="panel-title"><span>20500/-</span></h3></div>
		  </div>  
	  </div>
  </div>
  <div class="panel panel-danger">
	  <div class="panel-heading">
	    <div class="row">
	    <div class=col-sm-2><h3 class="panel-title">Travel1</h3></div>
	     <div  style="text-align:right"><h3 class="panel-title"><span>25 may 2017 - 28 may 2017</span></h3></div>
	    </div>
	  </div>
	  <div class="panel-body">
		  <div class="row">
		    <div class=col-sm-2><h3 class="panel-title">Suraj,Ramesh</h3></div>
		     <div style="text-align:right"><h3 class="panel-title"><span>20500/-</span></h3></div>
		  </div>  
	  </div>
  </div>  <div class="panel panel-danger">
	  <div class="panel-heading">
	    <div class="row">
	    <div class=col-sm-2><h3 class="panel-title">Travel1</h3></div>
	     <div  style="text-align:right"><h3 class="panel-title"><span>25 may 2017 - 28 may 2017</span></h3></div>
	    </div>
	  </div>
	  <div class="panel-body">
		  <div class="row">
		    <div class=col-sm-2><h3 class="panel-title">Suraj,Ramesh</h3></div>
		     <div style="text-align:right"><h3 class="panel-title"><span>20500/-</span></h3></div>
		  </div>  
	  </div>
  </div>  <div class="panel panel-danger">
	  <div class="panel-heading">
	    <div class="row">
	    <div class=col-sm-2><h3 class="panel-title">Travel1</h3></div>
	     <div  style="text-align:right"><h3 class="panel-title"><span>25 may 2017 - 28 may 2017</span></h3></div>
	    </div>
	  </div>
	  <div class="panel-body">
		  <div class="row">
		    <div class=col-sm-2><h3 class="panel-title">Suraj,Ramesh</h3></div>
		     <div style="text-align:right"><h3 class="panel-title"><span>20500/-</span></h3></div>
		  </div>  
	  </div>
  </div>
</div>