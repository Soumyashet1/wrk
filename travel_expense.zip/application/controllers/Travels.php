<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Travels extends CI_Controller {
public function __construct()
{
 		parent::__construct();
		$this->load->model('travel_model');
}
public function index()//shows all travels list
{
		$data['travel']=$this->travel_model->get_all_travels();
		$data['contents'] = "travels/travel_page";
		$this->load->view('layouts/navbar',$data);
}
}
